<html>
  <head><title>pizza calculator</title>
  <! This program calculate the amount of pizza a host will need to satisfy his guess
    the program calculate how many small pizza, or medium pizza or large pizza he will
    need to order for a particular input.This program tells the host how many small, or medium or Large
    pizza needed for the guest so that he will know if he should order small, or medium or large or divide the guest and Order
    for the three type of Pizzas, The program uses the ceil function to round up decimal values e.g if 5 guests can eat 1 slice
    pizza, The host will order 2 small pizzas, or 1 medium pizza or 1 large pizza(He need 2 small pizza because, We have 4 slices
    and need extra 1 slice to satisfy the guests making it two small pizzas, he will have extra 3 slices left)>

    <style type="text/css">
      #container, .result {
        margin-left:auto;
        margin-right:auto;
        width: 450px;
        border:solid;
        border-width: thin;
        border-radius: 10px 10px 0px 0px;
        border-color: #E0E0E0;
        min-width:50px;
        background-color: #ECEFF1;
                  }
      hr{
        margin-top: -20px;
        border-style: inset;
        }
      h3{
        padding-bottom : -30px;
        text-align: left;
        margin-top: 0px;
        margin-left: 0px;
        background-color: silver;
        border-radius: 10px 10px 0px 0px;
        }
      label{
        margin-left: 10px;
        text-align: right;
        width: 1%;
          }
      input[type='number']{
            width: 250px;
            margin-left: 10px;
                          }
      input[type="submit"]{
         color:#FFFFFF;
         background-color:#039BE5;
         margin-left:200px;
         border-style:solid;
         border-width:1px;
         border-radius: 4px;
         border-color: #039BE5;
         height:30px;
         -webkit-box-shadow: #B3B3B3 4px 4px 4px;
         -moz-box-shadow: #B3B3B3 7px 7px 7px;
         -moz-box-shadow: #B3B3B3 7px 7px 7px;"
                        }
      #ComentForInput{
        color: #99A3A4;
        font-size: 13px;
        margin-left: 130px;
        margin-top: -15px;
          }
      </style>
  </head>
      <body>
        <form   method="POST">
          <div id="container">
              <h3>Pizza Calculator</h3><hr/>
              <label for="1_slices">  1 slice of pizza &nbsp</label>
                <input type="number" size="30px" name="1slices" id="1_slices" />
                <div id="ComentForInput"><br/>People that can eat 1 slice of pizza</div><br/>
              <label for="2_slices"> 2 slices of pizza</label>
                <input type="number" size="30px"  name="2slices" id="2_slices" />
                <div id="ComentForInput"><br/>People that can eat 2 slices of pizza</div><br/>
              <label for="3_slices"> 3 slices of pizza </label>
                <input type="number" size="30px"  name="3slices" id="3_slices" />
                <div id="ComentForInput"><br/>People that can eat 3 slices of pizza</div><br/>
              <label for="4_slices"> 4 slices of pizza </label>
                <input type="number" size="20px" name="4slices" id="4_slices" />
                <div id="ComentForInput"><br/>People that can eat 4 slices of pizza</div><br/><br/>
                <input type="submit" value="Calculate" /><br/><br/>
        </div>
    </form>
      <?php
          if (isset($_POST["1slices"])) {
            $oneslice = $_POST["1slices"];
            $twoslice = $_POST["2slices"];
            $threeslice = $_POST["3slices"];
            $fourslice = $_POST["4slices"];
            $total = ($oneslice + (2*$twoslice) + (3*$threeslice) + (4*$fourslice));
            echo '<div class="result">';
                //check to see if the user enters a valid input, i.e Not a negative number
                //print out invalid input if the user enters a negative number
                if ($oneslice<0 || $twoslice<0 || $threeslice<0 || $fourslice<0) {
                        echo "One of your input or all of your input is INVALID, Please enter a VALID input (positive number)<br/><br/>";
                      }
                else {
                        echo "<p>Small Pizza(s) : ".ceil(($total/4))."</p>";
                        echo "<p>Medium Pizza(s) : ".ceil($total/6)."</p>";
                        echo "<p>Large Pizza(s) : ".ceil($total/8)."</p>";
                      }
            echo "</div>";
             }
        ?>
    </body>
</html>
